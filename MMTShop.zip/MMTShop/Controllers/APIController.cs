﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MMTShop.Model;
using MMTShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {
        private readonly MMTShopContext _context;

        public APIController(MMTShopContext context)
        {
            _context = context;
        }

        [HttpGet("GetCategoryList")]
        [ProducesResponseType(typeof(CategoryList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CategoryList), StatusCodes.Status400BadRequest)]
        public async Task<List<CategoryData>> GetCategoryList()
        {
            try
            {
                List<CategoryData> _objList = new List<CategoryData>();

                var result = await _context.SP_GetCategoryList.FromSqlRaw("EXECUTE [dbo].[SP_GetCategoryList]").ToListAsync();
                if (result.Count > 0)
                {
                    result.ForEach(s =>
                    {
                        CategoryData data = new CategoryData();
                        data.CategoryId = s.CategoryId;
                        data.Name = Convert.ToString(s.Name);
                        data.IsActive = Convert.ToBoolean(s.IsActive);
                        data.IsDeleted = Convert.ToBoolean(s.IsDeleted);
                        data.CreatedOn = s.CreatedOn;
                        data.ModifiedOn = s.ModifiedOn;
                        _objList.Add(data);
                    });

                    return _objList;
                }
                else
                { return null; }

            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet("GetAllProducts")]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status400BadRequest)]
        public async Task<List<ProductData>> GetAllProducts()
        {
            try
            {
                List<ProductData> _objList = new List<ProductData>();

                var result = await _context.SP_GetProductList.FromSqlRaw("EXECUTE [dbo].[SP_GetProductList]").ToListAsync();
                if (result.Count > 0)
                {
                    result.ForEach(s =>
                    {
                        ProductData data = new ProductData();
                        data.ProductId = s.ProductId;
                        data.CategoryId = s.CategoryId;
                        data.Sku = Convert.ToString(s.Sku);
                        data.Name = Convert.ToString(s.Name);
                        data.Price = Convert.ToString(s.Price + " GBP");
                        data.Description = Convert.ToString(s.Description);
                        data.IsActive = Convert.ToBoolean(s.IsActive);
                        data.IsDeleted = Convert.ToBoolean(s.IsDeleted);
                        data.CreatedOn = s.CreatedOn;
                        data.ModifiedOn = s.ModifiedOn;
                        _objList.Add(data);
                    });

                    return _objList;
                }
                else
                { return null; }
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet("GetFeatureProducts")]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status400BadRequest)]
        public async Task<List<ProductData>> GetFeatureProducts()
        {
            try
            {
                List<ProductData> _objList = new List<ProductData>();

                var result = await _context.SP_GetProductList.FromSqlRaw("EXECUTE [dbo].[SP_GetProductList]").ToListAsync();
                if (result.Count > 0)
                {
                    result.Where(a => a.Sku >= 10000 && a.Sku < 40000).ToList().ForEach(s =>
                    {
                        ProductData data = new ProductData();
                        data.ProductId = s.ProductId;
                        data.CategoryId = s.CategoryId;
                        data.Sku = Convert.ToString(s.Sku);
                        data.Name = Convert.ToString(s.Name);
                        data.Price = Convert.ToString(s.Price + " GBP");
                        data.Description = Convert.ToString(s.Description);
                        data.IsActive = Convert.ToBoolean(s.IsActive);
                        data.IsDeleted = Convert.ToBoolean(s.IsDeleted);
                        data.CreatedOn = s.CreatedOn;
                        data.ModifiedOn = s.ModifiedOn;
                        _objList.Add(data);
                    });

                    return _objList;
                }
                else
                { return null; }
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet("GetProductsbyCategory/{catid}")]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProductList), StatusCodes.Status400BadRequest)]
        public async Task<List<ProductData>> GetProductsbyCategory(Guid catid)
        {
            try
            {
                List<ProductData> _objList = new List<ProductData>();

                var result = await _context.SP_GetProductList.FromSqlRaw("EXECUTE [dbo].[SP_GetProductList]").ToListAsync();
                
                if (result.Count > 0)
                {
                    result.Where(a => a.CategoryId == catid).ToList().ForEach(s =>
                    {
                        ProductData data = new ProductData();
                        data.ProductId = s.ProductId;
                        data.CategoryId = s.CategoryId;
                        data.Sku = Convert.ToString(s.Sku);
                        data.Name = Convert.ToString(s.Name);
                        data.Price = Convert.ToString(s.Price + " GBP");
                        data.Description = Convert.ToString(s.Description);
                        data.IsActive = Convert.ToBoolean(s.IsActive);
                        data.IsDeleted = Convert.ToBoolean(s.IsDeleted);
                        data.CreatedOn = s.CreatedOn;
                        data.ModifiedOn = s.ModifiedOn;
                        _objList.Add(data);
                    });

                    return _objList;
                }
                else
                { return null; }

            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
