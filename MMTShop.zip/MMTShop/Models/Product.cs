﻿using System;
using System.Collections.Generic;

namespace MMTShop.Models
{
    public partial class Product
    {
        public Guid ProductId { get; set; }
        public Guid? CategoryId { get; set; }
        public long? Sku { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal? Price { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
