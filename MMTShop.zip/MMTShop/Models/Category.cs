﻿using System;
using System.Collections.Generic;

namespace MMTShop.Models
{
    public partial class Category
    {
        public Guid CategoryId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
