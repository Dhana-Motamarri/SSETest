﻿using MMTShop.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public static HttpClient webclient = new HttpClient();
        static void Main(string[] args)
        {
            Program program = new Program();

            //Program 1 to get all the categories
            program.GetCategoryList();

            //Program 2 to get all the products
            //program.GetAllProducts();

            //Program 3 to get all the featured products with SKU codes in the range 1xxxx, 2xxxx and 3xxxx.
            //program.GetFeatureProducts();

            //Program 4 list of all available products within that category
            //program.GetProductsbyCategory(Guid.Parse("4BD1512F-F56D-47DD-8678-A4999B046679"));
        }

        private void GetCategoryList()
        {
            List<CategoryData> categories = new List<CategoryData>();
            HttpResponseMessage response = webclient.GetAsync("http://localhost:8173/api/API/GetCategoryList").Result;
            categories = response.Content.ReadAsAsync<List<CategoryData>>().Result;

            foreach(CategoryData catData in categories)
            {
                Console.WriteLine(catData.Name);
            }
        }

        private void GetAllProducts()
        {
            List<ProductData> products = new List<ProductData>();
            HttpResponseMessage response = webclient.GetAsync("http://localhost:8173/api/API/GetAllProducts").Result;
            products = response.Content.ReadAsAsync<List<ProductData>>().Result;

            foreach (ProductData proData in products)
            {
                Console.WriteLine("-ProductName-" + proData.Name + "-SKU-" + proData.Sku + "-Price-" + proData.Price );
            }
        }

        private void GetFeatureProducts()
        {
            List<ProductData> products = new List<ProductData>();
            HttpResponseMessage response = webclient.GetAsync("http://localhost:8173/api/API/GetFeatureProducts").Result;
            products = response.Content.ReadAsAsync<List<ProductData>>().Result;

            foreach (ProductData proData in products)
            {
                Console.WriteLine("-ProductName-" + proData.Name + "-SKU-" + proData.Sku + "-Price-" + proData.Price);
            }
        }

        private void GetProductsbyCategory(Guid catid)
        {
            List<ProductData> products = new List<ProductData>();
            HttpResponseMessage response = webclient.GetAsync("http://localhost:8173/api/API/GetProductsbyCategory/" + catid).Result;
            products = response.Content.ReadAsAsync<List<ProductData>>().Result;

            foreach (ProductData proData in products)
            {
                Console.WriteLine("-ProductName-" + proData.Name + "-SKU-" + proData.Sku + "-Price-" + proData.Price);
            }
        }
    }
}
